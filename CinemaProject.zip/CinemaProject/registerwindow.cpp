#include "registerwindow.h"
#include "ui_registerwindow.h"
#include "Users.h"
#include <QString>
#include "welcomewindow.h"
#include "QLabel"

RegisterWindow::RegisterWindow(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::RegisterWindow)
{
    ui->setupUi(this);
    ui->label_already->setVisible(false);
    ui->label_match->setVisible(false);
    ui->label_age_2->setVisible(false);
    ui->label_all->setVisible(false);
}




RegisterWindow::~RegisterWindow()
{
    delete ui;
}


void RegisterWindow::on_pushButton_clicked()
{
    QString usernameRegister = ui->lineEdit_username->text();
    static QString newUsername;

    for(int i = 0; i < usersCount; i++){
         if(usernameRegister == usernames[i]){
            ui->label_already->setVisible(true);
             break;
        }
         else if(usernameRegister != usernames[i]) {
             ui->label_already->setVisible(false);
            newUsername = usernameRegister;
         }
    }


    QString passwordRegister = ui->lineEdit_password->text();
    QString repasswordRegister = ui->lineEdit_repassword->text();

    if(passwordRegister != repasswordRegister){
        ui->label_match->setVisible(true);
    }
    else if(passwordRegister == repasswordRegister){
        ui->label_match->setVisible(false);
        QString newPassword = passwordRegister;
        passwords[usersCount++] = newPassword;
    }

    QString month = ui->comboBox_month_2->currentText();
    QString dayS = ui->lineEdit_day_2->text();
    QString yearS = ui->lineEdit_year->text();
    int year = yearS.toInt();
    int day = dayS.toInt();

    static int newAge;
    if(2024 - year < 12){
        ui->label_age_2->setVisible(true);
    }
    else if(2024 - year > 12){
        ui->label_age_2->setVisible(false);
        newAge = 2024 - year;
        ages[usersCount++] = newAge;
        usersCount++;
    }

    bool male = ui->radioButton_male_2->isChecked();
    bool female = ui->radioButton_female_2->isChecked();
    bool user = ui->radioButton_user_2->isChecked();
    bool admin = ui->radioButton_admin_2->isChecked();
    bool comedy = ui->checkBox_comedy_2->isChecked();
    bool horror = ui->checkBox_horror_2->isChecked();
    bool action = ui->checkBox_action_2->isChecked();
    bool drama = ui->checkBox_drama_2->isChecked();
    bool other = ui->checkBox_othe_2->isChecked();
    bool romance = ui->checkBox_romanc_2->isChecked();

    if(male == false && female == false){
        ui->label_all->setVisible(true);
    }
    else if(user == false && admin == false){
        ui->label_all->setVisible(true);
    }
    else if (comedy == false && horror == false && action == false && drama == false && other == false && romance == false){
        ui->label_all->setVisible(true);
    }
    else {
        ui->label_all->setVisible(false);
    }

    if (!ui->label_all->isVisible() && !ui->label_already->isVisible() && !ui->label_age_2->isVisible() && !ui->label_match->isVisible()) {
        WelcomeWindow* welcomeWindow = new WelcomeWindow(newUsername, newAge, this);
        welcomeWindow->show();
    }

}
