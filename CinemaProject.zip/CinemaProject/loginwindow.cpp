#include "loginwindow.h"
#include "ui_loginwindow.h"
#include "Users.h"
#include <QMessageBox>
#include <iostream>
#include "welcomewindow.h"
#include "registerwindow.h"


LoginWindow::LoginWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::LoginWindow)
{
    ui->setupUi(this);
    ui->label_error->setVisible(false);
}

LoginWindow::~LoginWindow()
{
    delete ui;
}


void LoginWindow::on_pushButton_Login_clicked(){

    QString username = ui->lineEdit_Username->text();
    QString password = ui->lineEdit_Password->text();

    for(int i = 0; i < usersCount; i++){
            if(usernames[i] == username && passwords[i] == password){
            QString theUsername = usernames[i];
                int theAge = ages[i];
                hide();
                WelcomeWindow* welcomeWindow = new WelcomeWindow(theUsername, theAge, this);
                welcomeWindow->show();
                break;
            }
            else{
               ui->label_error->setVisible(true);
            }
    }

}

void LoginWindow::on_pushButton_Register_clicked()
{
    hide();
    RegisterWindow* registerWindow = new RegisterWindow(this);
    registerWindow->show();
}


