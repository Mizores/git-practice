#include "welcomewindow.h"
#include "ui_welcomewindow.h"
#include <QPixmap>
#include "loginwindow.h"
#include <QString>

WelcomeWindow::WelcomeWindow(QString username, int age, QWidget *parent)
    : QDialog(parent), ui(new Ui::WelcomeWindow)
{
    ui->setupUi(this);
    QString str = QString::number(age);
    ui->label_user->setText("Hello " + username + " " + str);
    QPixmap pix("C:\\Users\\moham\\Documents\\CinemaProject\\cinemapop.jpeg");
    int w = ui->label_image->width();
    int h =ui->label_image->height();
    ui->label_image->setPixmap(pix.scaled(w,h, Qt::KeepAspectRatio));
}

WelcomeWindow::~WelcomeWindow()
{

    delete ui;
}

void WelcomeWindow::on_pushButton_logout_clicked()
{
    hide();
    LoginWindow* loginWindow = new LoginWindow(this);
    loginWindow->show();
}

